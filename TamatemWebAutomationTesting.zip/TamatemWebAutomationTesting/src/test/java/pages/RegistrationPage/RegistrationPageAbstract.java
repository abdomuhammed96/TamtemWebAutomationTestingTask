package pages.RegistrationPage;

public abstract class RegistrationPageAbstract extends RegistrationPagePO {



    public abstract void Register() throws InterruptedException;


}
