package pages.HomePage;

public abstract class HomePageAbstract extends HomeMainPO {




    public abstract void clickOnElementOnHomePage(String arg0);



}
