# SMAPI-Testing-Automation
For the Automation code for testing scenarios for Our Platforms: RN Android & Web
